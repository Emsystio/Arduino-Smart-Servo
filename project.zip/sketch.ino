//Those seeing from Github: Advised to see from Laptop
// Project description:  Project on Remote controlling a servo
//C ++ Code
//Intsalling Libraries
#include <LiquidCrystal.h>
#include <Servo.h>
#include <IRremote.h>

//Creating Variables
int j;
int speed;
String input;
String msg="Enter your name: ";
int IRpin=18;
String Remotecontrol;
decode_results cmd;
IRrecv IR(IRpin);
Servo myServo;
LiquidCrystal lcd(7,8,9,10,11,12);
int swival;
int ultratime;

void setup(){
  lcd. begin (16,2);
  myServo.attach(2);
  IR.enableIRIn();
  Serial.begin(9600);
  pinMode(3,INPUT);
  pinMode(13,OUTPUT);
  pinMode(5,INPUT);
  pinMode(6,OUTPUT);
}

void loop(){
  while(IR.decode(&cmd)==0){

  }
  IR.resume();
  Serial.println(cmd.value,HEX);

  
  Serial.println(msg);
  while(Serial.available()==0){

  }
  
  digitalWrite(6,LOW);
  delayMicroseconds(10);
  digitalWrite(6,HIGH);
  delayMicroseconds(10);
  digitalWrite(6,LOW);
  ultratime=pulseIn(5,HIGH);
  delay(25);
  input=Serial.parseInt();
  swival=digitalRead(3);
  if(swival==0){
    lcd.setCursor(0,0);
    lcd.print("Hello",input);
    delay(1000);
    lcd. clear();
    if(ultratime < 300){
      lcd.setCursor(0,0);
      lcd.print("Set speed Remote");
      
      //When the user clicks 1 in the remote
      if (cmd.value==0xFF0CF3){
        for (j=1; j<= 18; j=j+1){
          myServo.write(20);
          delay(100);
        }
      }

      //When the user clicks 2 in the remote
      if (cmd.value== 0xFF18E7){
        for (j=1; j<=12; j=j+1){
          myServo.write(30);
          delay(100);
        }
      }
      
      if(cmd.value==0xFF5EA1){
        for(j=1; j<=6; j=j+1){
          myServo.write(60);
          delay(100);
        }
      }

      if(cmd.value==0xFF08F7){
        for(j=1; j<=3; j=j+1){
          myServo.write(120);
          delay(100);
        }
      }

      if(cmd.value==0xFF1CE3){
        for(j=1; j<=2; j=j+1){
          myServo.write(180);
          delay(100);
        }
      }

      }

    }
  }
  
  
}
